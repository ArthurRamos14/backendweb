
const express = require('express');
const mysql = require('mysql2');

const app = express();
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'pi'
});

db.connect((err) => {
  if (err) {
    console.log(err);
    return;
  }
  console.log('Conectado ao MySQL!');
});


app.get('/treino', (req, res) => {
    console.log('Entrou na rota GET');
    res.json([{ id: 1, nome: 'Teste' }]);
});


app.post('/treino', (req, res) => {
  const { nome, descricao } = req.body;

  db.query(
    'INSERT INTO treino (nome, descricao) VALUES (?, ?)',
    [nome, descricao],
    (err, resultado) => {
      if (err) return res.status(500).json(err);

      res.json({
        mensagem: 'Treino cadastrado!',
        id: resultado.insertId
      });
    }
  );
});


app.put('/treino/:id', (req, res) => {
  const { nome, descricao } = req.body;
  const { id } = req.params;

  db.query(
    'UPDATE treino SET nome = ?, descricao = ? WHERE id = ?',
    [nome, descricao, id],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ mensagem: 'Treino atualizado!' });
    }
  );
});


app.delete('/treino/:id', (req, res) => {
  const { id } = req.params;

  db.query(
    'DELETE FROM treino WHERE id = ?',
    [id],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ mensagem: 'Treino excluído!' });
    }
  );
});

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
