const readline = require('readline-sync');

let palavraMisteriosa = "TERRA";

let ganhou = false;

for (let tentativa = 1; tentativa <= 6; tentativa++) {

    let palpite = readline.question(`Tentativa ${tentativa}: `).toUpperCase();

    if (palpite === palavraMisteriosa) {
        console.log("Parabéns! Você acertou!");
        ganhou = true;
        break;
    }

    let resultado = "";

    for (let i = 0; i < 5; i++) {
        if (palpite[i] === palavraMisteriosa[i]) {
            resultado += "[V] ";
        } else if (palavraMisteriosa.includes(palpite[i])) {
            resultado += "[?] ";
        } else {
            resultado += "[X] ";
        }
    }

    console.log(resultado);
}

if (!ganhou) {
    console.log("Você perdeu! A palavra era: " + palavraMisteriosa);
}